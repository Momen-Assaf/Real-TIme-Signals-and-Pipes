#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <signal.h>

#define KEY 500


#include <GL/glut.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
